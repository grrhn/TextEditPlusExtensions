// Text Tools — demonstrates the Commands API.
// Registers four palette commands that transform either the selection or
// the entire document if there is no selection.

function transform(fn) {
  var sel = editor.getSelection();
  var model = editor.getModel();
  if (!model) return;
  var range = (sel && !sel.isEmpty()) ? sel : model.getFullModelRange();
  var original = model.getValueInRange(range);
  var replaced = fn(original);
  editor.executeEdits('text-tools', [{ range: range, text: replaced }]);
}

TextEditPlus.commands.register({
  id: 'text-tools.upper',
  name: 'Text Tools: UPPERCASE',
  description: 'Convert selection (or document) to uppercase',
  exec: function() { transform(function(s) { return s.toUpperCase(); }); }
}, extensionId);

TextEditPlus.commands.register({
  id: 'text-tools.lower',
  name: 'Text Tools: lowercase',
  description: 'Convert selection (or document) to lowercase',
  exec: function() { transform(function(s) { return s.toLowerCase(); }); }
}, extensionId);

TextEditPlus.commands.register({
  id: 'text-tools.sort',
  name: 'Text Tools: Sort Lines',
  description: 'Sort lines alphabetically (case-insensitive)',
  exec: function() {
    transform(function(s) {
      return s.split(/\r?\n/).sort(function(a, b) {
        return a.toLowerCase().localeCompare(b.toLowerCase());
      }).join('\n');
    });
  }
}, extensionId);

TextEditPlus.commands.register({
  id: 'text-tools.dedupe',
  name: 'Text Tools: Remove Duplicate Lines',
  description: 'Drop consecutive duplicate lines',
  exec: function() {
    transform(function(s) {
      var seen = {};
      return s.split(/\r?\n/).filter(function(line) {
        if (seen[line]) return false;
        seen[line] = true;
        return true;
      }).join('\n');
    });
  }
}, extensionId);

TextEditPlus.commands.register({
  id: 'text-tools.trim',
  name: 'Text Tools: Trim Trailing Whitespace',
  description: 'Strip trailing spaces/tabs from every line',
  exec: function() {
    transform(function(s) {
      return s.split(/\r?\n/).map(function(line) {
        return line.replace(/[ \t]+$/, '');
      }).join('\n');
    });
  }
}, extensionId);

TextEditPlus.toast('Text Tools ready — open the Command Palette', 'success', 2500);
