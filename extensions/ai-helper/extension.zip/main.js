// AI Helper — exercises every Settings API widget type.
// Open the app's Settings dialog and scroll down to "EXTENSIONS" — you'll
// see this extension's four configurable fields rendered with the right
// widget per type.

TextEditPlus.settings.define({
  schema: [
    {
      key: 'apiKey',
      type: 'string',
      label: 'API Key',
      secret: true,
      default: ''
    },
    {
      key: 'model',
      type: 'enum',
      label: 'Model',
      options: [
        { value: 'gpt-4o-mini', label: 'GPT-4o mini' },
        { value: 'gpt-4o',      label: 'GPT-4o' },
        { value: 'claude-haiku', label: 'Claude Haiku' }
      ],
      default: 'gpt-4o-mini'
    },
    {
      key: 'maxTokens',
      type: 'int',
      label: 'Max tokens',
      default: 2000,
      min: 100,
      max: 8000
    },
    {
      key: 'streamResponses',
      type: 'boolean',
      label: 'Stream responses',
      default: true
    }
  ]
}, extensionId);

// React to setting changes (e.g. show a toast when the model changes).
TextEditPlus.settings.onChange(extensionId, function(key, newVal) {
  if (key === 'model') {
    TextEditPlus.toast('AI model changed to ' + newVal, 'info', 2000);
  }
});

// A command that reads current settings — proves get() returns persisted
// values after the user changes them in Settings.
TextEditPlus.commands.register({
  id: 'ai-helper.show-config',
  name: 'AI Helper: Show current config',
  description: 'Display the persisted settings values',
  exec: function() {
    var s = TextEditPlus.settings;
    var msg =
      'API Key: '   + (s.get(extensionId, 'apiKey') ? '(set)' : '(empty)') + '\n' +
      'Model: '     + s.get(extensionId, 'model') + '\n' +
      'Max tokens: ' + s.get(extensionId, 'maxTokens') + '\n' +
      'Streaming: ' + (s.get(extensionId, 'streamResponses') ? 'on' : 'off');
    TextEditPlus.dialog.alert(msg, 'AI Helper');
  }
}, extensionId);
