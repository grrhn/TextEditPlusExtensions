TextEditPlus.themes.define('nord', {
  base: 'vs-dark', inherit: true,
  rules: [
    { token: 'comment',  foreground: '616e88', fontStyle: 'italic' },
    { token: 'keyword',  foreground: '81a1c1' },
    { token: 'string',   foreground: 'a3be8c' },
    { token: 'number',   foreground: 'b48ead' },
    { token: 'type',     foreground: '8fbcbb' },
    { token: 'function', foreground: '88c0d0' },
    { token: 'variable', foreground: 'd8dee9' },
    { token: 'constant', foreground: 'b48ead' },
    { token: 'operator', foreground: '81a1c1' },
    { token: 'delimiter', foreground: 'eceff4' }
  ],
  colors: {
    'editor.background':            '#2e3440',
    'editor.foreground':            '#d8dee9',
    'editor.lineHighlightBackground': '#3b4252',
    'editorCursor.foreground':      '#d8dee9',
    'editor.selectionBackground':   '#434c5e',
    'editorWhitespace.foreground':  '#434c5e',
    'editorLineNumber.foreground':  '#4c566a',
    'editorLineNumber.activeForeground': '#d8dee9'
  }
}, extensionId, 'Nord');
