TextEditPlus.themes.define('monokai', {
  base: 'vs-dark', inherit: true,
  rules: [
    { token: 'comment',  foreground: '88846f', fontStyle: 'italic' },
    { token: 'keyword',  foreground: 'f92672' },
    { token: 'string',   foreground: 'e6db74' },
    { token: 'number',   foreground: 'ae81ff' },
    { token: 'type',     foreground: '66d9ef', fontStyle: 'italic' },
    { token: 'function', foreground: 'a6e22e' },
    { token: 'variable', foreground: 'f8f8f2' },
    { token: 'constant', foreground: 'ae81ff' },
    { token: 'operator', foreground: 'f92672' },
    { token: 'delimiter', foreground: 'f8f8f2' }
  ],
  colors: {
    'editor.background':            '#272822',
    'editor.foreground':            '#f8f8f2',
    'editor.lineHighlightBackground': '#3e3d32',
    'editorCursor.foreground':      '#f8f8f0',
    'editor.selectionBackground':   '#49483e',
    'editorWhitespace.foreground':  '#3b3a32',
    'editorLineNumber.foreground':  '#90908a',
    'editorLineNumber.activeForeground': '#f8f8f2'
  }
}, extensionId, 'Monokai');
