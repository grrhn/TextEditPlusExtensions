// Markdown Preview — renders a minimal subset of Markdown in a sidebar panel.
// Not a full CommonMark parser; covers headings, bold/italic, inline code,
// fenced code blocks, links, lists, blockquotes, hr, and paragraphs. Good
// enough for README skimming on mobile.

function escapeHtml(s) {
  return s.replace(/[&<>"']/g, function(c) {
    return ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' })[c];
  });
}

function renderMarkdown(src) {
  var lines = src.split(/\r?\n/);
  var out = [];
  var inCode = false;
  var codeLines = [];
  var listType = null;
  var listItems = [];

  function flushList() {
    if (listType) {
      out.push('<' + listType + '>' + listItems.join('') + '</' + listType + '>');
      listType = null;
      listItems = [];
    }
  }

  function inline(text) {
    text = escapeHtml(text);
    // links: [text](url)
    text = text.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2">$1</a>');
    // bold
    text = text.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    text = text.replace(/__([^_]+)__/g, '<strong>$1</strong>');
    // italic
    text = text.replace(/(^|[^*])\*([^*]+)\*/g, '$1<em>$2</em>');
    text = text.replace(/(^|[^_])_([^_]+)_/g, '$1<em>$2</em>');
    // inline code
    text = text.replace(/`([^`]+)`/g, '<code>$1</code>');
    return text;
  }

  for (var i = 0; i < lines.length; i++) {
    var line = lines[i];
    if (line.match(/^```/)) {
      if (inCode) {
        out.push('<pre><code>' + codeLines.map(escapeHtml).join('\n') + '</code></pre>');
        codeLines = [];
        inCode = false;
      } else {
        flushList();
        inCode = true;
      }
      continue;
    }
    if (inCode) { codeLines.push(line); continue; }

    var h = line.match(/^(#{1,6})\s+(.+)$/);
    if (h) { flushList(); out.push('<h' + h[1].length + '>' + inline(h[2]) + '</h' + h[1].length + '>'); continue; }

    if (line.match(/^---+$/) || line.match(/^\*\*\*+$/)) { flushList(); out.push('<hr>'); continue; }

    var bq = line.match(/^>\s?(.*)$/);
    if (bq) { flushList(); out.push('<blockquote>' + inline(bq[1]) + '</blockquote>'); continue; }

    var ul = line.match(/^[*\-+]\s+(.+)$/);
    if (ul) {
      if (listType !== 'ul') { flushList(); listType = 'ul'; }
      listItems.push('<li>' + inline(ul[1]) + '</li>');
      continue;
    }
    var ol = line.match(/^\d+\.\s+(.+)$/);
    if (ol) {
      if (listType !== 'ol') { flushList(); listType = 'ol'; }
      listItems.push('<li>' + inline(ol[1]) + '</li>');
      continue;
    }

    if (line.trim() === '') { flushList(); continue; }

    flushList();
    out.push('<p>' + inline(line) + '</p>');
  }
  flushList();
  if (inCode) out.push('<pre><code>' + codeLines.map(escapeHtml).join('\n') + '</code></pre>');

  return out.join('\n');
}

function refreshPreview() {
  var text = editor.getValue() || '';
  var rendered = renderMarkdown(text);
  TextEditPlus.sidebar.update('markdown-preview.panel',
    '<style>' +
      'h1,h2,h3{border-bottom:1px solid #444;padding-bottom:4px}' +
      'pre{background:#222;padding:8px;border-radius:4px;overflow-x:auto}' +
      'code{background:#222;padding:2px 4px;border-radius:2px;font-family:monospace}' +
      'pre code{background:none;padding:0}' +
      'blockquote{border-left:3px solid #555;padding-left:12px;color:#aaa;margin-left:0}' +
      'a{color:#4ea1ff}' +
    '</style>' +
    (rendered || '<p style="color:#888;font-style:italic">Empty document</p>') +
    '<hr><div style="text-align:center;margin-top:12px">' +
      '<button data-action="markdown-preview.refresh">Refresh</button>' +
    '</div>'
  );
}

TextEditPlus.commands.register({
  id: 'markdown-preview.refresh',
  name: 'Markdown Preview: Refresh',
  exec: refreshPreview
}, extensionId);

TextEditPlus.sidebar.register({
  id:    'markdown-preview.panel',
  title: 'Markdown',
  icon:  'MD',
  html:  '<p>Loading…</p>'
}, extensionId);

refreshPreview();
