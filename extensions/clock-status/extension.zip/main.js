// Clock Status — demonstrates setPluginInit and the destroy callback.
// Runs a 1-second timer; without proper teardown the timer would keep
// firing after the extension is disabled or the editor reloads, leaking
// CPU and producing console errors when it tries to update a panel
// that no longer exists.

TextEditPlus.sidebar.register({
  id:    'clock-status.panel',
  title: 'Clock',
  icon:  'CK',
  html:  '<p>Initializing…</p>'
}, extensionId);

TextEditPlus.setPluginInit(extensionId,
  function init() {
    var self = this;
    self.tick = function() {
      var now = new Date();
      TextEditPlus.sidebar.update('clock-status.panel',
        '<h3 style="margin-top:0">Clock</h3>' +
        '<p style="font-size:32px;text-align:center;font-family:monospace;margin:24px 0">' +
          now.toLocaleTimeString() +
        '</p>' +
        '<p style="color:#888;font-size:12px;text-align:center">Tick #' + (self.ticks++) + '</p>' +
        '<p style="color:#888;font-size:11px;text-align:center;margin-top:24px">' +
          'Stops cleanly when extension is disabled.' +
        '</p>'
      );
    };
    self.ticks = 0;
    self.timerId = setInterval(self.tick, 1000);
    self.tick();
    TextEditPlus.toast('Clock started', 'success', 1500);
  },
  function destroy() {
    // Without this, the interval would survive the extension and keep
    // calling sidebar.update on a panel id that no longer exists.
    clearInterval(this.timerId);
    TextEditPlus.toast('Clock stopped', 'info', 1500);
  }
);
