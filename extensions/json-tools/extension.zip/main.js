// JSON Tools — four palette commands for working with JSON.

function transformWhole(fn) {
  var model = editor.getModel();
  if (!model) return;
  var range = model.getFullModelRange();
  try {
    var result = fn(model.getValue());
    editor.executeEdits('json-tools', [{ range: range, text: result }]);
  } catch (e) {
    TextEditPlus.toast('JSON error: ' + e.message, 'error', 3000);
  }
}

function sortKeys(obj) {
  if (Array.isArray(obj)) return obj.map(sortKeys);
  if (obj && typeof obj === 'object') {
    var sorted = {};
    Object.keys(obj).sort().forEach(function(k) { sorted[k] = sortKeys(obj[k]); });
    return sorted;
  }
  return obj;
}

TextEditPlus.commands.register({
  id: 'json-tools.format',
  name: 'JSON: Pretty-print',
  description: 'Format with 2-space indentation',
  exec: function() {
    transformWhole(function(src) { return JSON.stringify(JSON.parse(src), null, 2); });
    TextEditPlus.toast('JSON formatted', 'success', 1200);
  }
}, extensionId);

TextEditPlus.commands.register({
  id: 'json-tools.minify',
  name: 'JSON: Minify',
  description: 'Strip all whitespace',
  exec: function() {
    transformWhole(function(src) { return JSON.stringify(JSON.parse(src)); });
    TextEditPlus.toast('JSON minified', 'success', 1200);
  }
}, extensionId);

TextEditPlus.commands.register({
  id: 'json-tools.sort-keys',
  name: 'JSON: Sort keys',
  description: 'Recursively sort object keys alphabetically',
  exec: function() {
    transformWhole(function(src) { return JSON.stringify(sortKeys(JSON.parse(src)), null, 2); });
    TextEditPlus.toast('Keys sorted', 'success', 1200);
  }
}, extensionId);

TextEditPlus.commands.register({
  id: 'json-tools.validate',
  name: 'JSON: Validate',
  description: 'Check if the document parses as JSON',
  exec: function() {
    var model = editor.getModel();
    if (!model) return;
    try {
      JSON.parse(model.getValue());
      TextEditPlus.toast('Valid JSON', 'success', 1500);
    } catch (e) {
      TextEditPlus.dialog.alert('Parse error:\n' + e.message, 'JSON Tools');
    }
  }
}, extensionId);
