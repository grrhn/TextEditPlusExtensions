TextEditPlus.themes.define('github-dark', {
  base: 'vs-dark', inherit: true,
  rules: [
    { token: 'comment',  foreground: '8b949e', fontStyle: 'italic' },
    { token: 'keyword',  foreground: 'ff7b72' },
    { token: 'string',   foreground: 'a5d6ff' },
    { token: 'number',   foreground: '79c0ff' },
    { token: 'type',     foreground: 'ffa657' },
    { token: 'function', foreground: 'd2a8ff' },
    { token: 'variable', foreground: 'c9d1d9' },
    { token: 'constant', foreground: '79c0ff' },
    { token: 'operator', foreground: 'ff7b72' },
    { token: 'delimiter', foreground: 'c9d1d9' }
  ],
  colors: {
    'editor.background':            '#0d1117',
    'editor.foreground':            '#c9d1d9',
    'editor.lineHighlightBackground': '#161b22',
    'editorCursor.foreground':      '#c9d1d9',
    'editor.selectionBackground':   '#264f78',
    'editorWhitespace.foreground':  '#21262d',
    'editorLineNumber.foreground':  '#484f58',
    'editorLineNumber.activeForeground': '#c9d1d9'
  }
}, extensionId, 'GitHub Dark');
