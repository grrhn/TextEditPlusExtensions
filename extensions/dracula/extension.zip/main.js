TextEditPlus.themes.define('dracula', {
  base: 'vs-dark', inherit: true,
  rules: [
    { token: 'comment',  foreground: '6272a4', fontStyle: 'italic' },
    { token: 'keyword',  foreground: 'ff79c6' },
    { token: 'string',   foreground: 'f1fa8c' },
    { token: 'number',   foreground: 'bd93f9' },
    { token: 'type',     foreground: '8be9fd', fontStyle: 'italic' },
    { token: 'function', foreground: '50fa7b' },
    { token: 'variable', foreground: 'f8f8f2' },
    { token: 'constant', foreground: 'bd93f9' },
    { token: 'operator', foreground: 'ff79c6' },
    { token: 'delimiter', foreground: 'f8f8f2' }
  ],
  colors: {
    'editor.background':            '#282a36',
    'editor.foreground':            '#f8f8f2',
    'editor.lineHighlightBackground': '#44475a',
    'editorCursor.foreground':      '#f8f8f2',
    'editor.selectionBackground':   '#44475a',
    'editorWhitespace.foreground':  '#3b3a4e',
    'editorLineNumber.foreground':  '#6272a4',
    'editorLineNumber.activeForeground': '#f8f8f2'
  }
}, extensionId, 'Dracula');
