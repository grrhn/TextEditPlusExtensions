// Quick Actions — exercises the Sidebar API.
// Registers four commands and a panel. The panel shows live document stats
// and has buttons that invoke the commands via the panel's `data-action`
// attribute (handled by the host bootstrap).

function transform(fn) {
  var sel = editor.getSelection();
  var model = editor.getModel();
  if (!model) return;
  var range = (sel && !sel.isEmpty()) ? sel : model.getFullModelRange();
  editor.executeEdits('quick-actions', [{ range: range, text: fn(model.getValueInRange(range)) }]);
}

TextEditPlus.commands.register({
  id: 'quick-actions.upper',
  name: 'Quick Actions: UPPERCASE',
  exec: function() { transform(function(s) { return s.toUpperCase(); }); }
}, extensionId);

TextEditPlus.commands.register({
  id: 'quick-actions.lower',
  name: 'Quick Actions: lowercase',
  exec: function() { transform(function(s) { return s.toLowerCase(); }); }
}, extensionId);

TextEditPlus.commands.register({
  id: 'quick-actions.duplicate',
  name: 'Quick Actions: Duplicate line',
  exec: function() {
    var pos = editor.getPosition();
    if (!pos) return;
    var model = editor.getModel();
    var line = model.getLineContent(pos.lineNumber);
    editor.executeEdits('quick-actions', [{
      range: new monaco.Range(pos.lineNumber, model.getLineMaxColumn(pos.lineNumber),
                              pos.lineNumber, model.getLineMaxColumn(pos.lineNumber)),
      text: '\n' + line
    }]);
  }
}, extensionId);

TextEditPlus.commands.register({
  id: 'quick-actions.refresh-stats',
  name: 'Quick Actions: Refresh stats',
  exec: function() { renderPanel(); }
}, extensionId);

function renderPanel() {
  var text = editor.getValue() || '';
  var chars = text.length;
  var lines = text === '' ? 0 : text.split(/\r?\n/).length;
  var words = text.trim() === '' ? 0 : text.trim().split(/\s+/).length;

  TextEditPlus.sidebar.update('quick-actions.panel',
    '<h3 style="margin-top:0">Document stats</h3>' +
    '<table style="border-collapse:collapse;width:100%;margin-bottom:16px;">' +
      '<tr><td style="padding:4px 0;color:#888">Lines</td><td style="text-align:right;font-weight:bold">' + lines + '</td></tr>' +
      '<tr><td style="padding:4px 0;color:#888">Words</td><td style="text-align:right;font-weight:bold">' + words + '</td></tr>' +
      '<tr><td style="padding:4px 0;color:#888">Characters</td><td style="text-align:right;font-weight:bold">' + chars + '</td></tr>' +
    '</table>' +
    '<h3>Actions</h3>' +
    '<div style="display:flex;flex-direction:column;gap:6px">' +
      '<button data-action="quick-actions.upper">UPPERCASE</button>' +
      '<button data-action="quick-actions.lower">lowercase</button>' +
      '<button data-action="quick-actions.duplicate">Duplicate line</button>' +
      '<button data-action="quick-actions.refresh-stats">Refresh stats</button>' +
    '</div>'
  );
}

// Initial registration with placeholder content.
TextEditPlus.sidebar.register({
  id:    'quick-actions.panel',
  title: 'Quick Actions',
  icon:  'QA',
  html:  '<p>Loading…</p>'
}, extensionId);

renderPanel();
