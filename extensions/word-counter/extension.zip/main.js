// Word Counter Demo — exercises Toast, Dialog.alert, Dialog.confirm, Dialog.prompt.
// Triggered automatically on load just for the sample; in real life this would
// be wired to a command/sidebar button (next API phases).

(async function() {
  TextEditPlus.toast('Word Counter loaded', 'success', 2000);

  var text = editor.getValue() || '';
  var words = text.trim() === '' ? 0 : text.trim().split(/\s+/).length;

  await TextEditPlus.dialog.alert(
    'Document has ' + words + ' words.',
    'Word Counter'
  );

  var detailed = await TextEditPlus.dialog.confirm(
    'Show character and line breakdown too?',
    'Word Counter'
  );

  if (detailed) {
    var chars = text.length;
    var lines = text === '' ? 0 : text.split(/\r?\n/).length;
    await TextEditPlus.dialog.alert(
      'Characters: ' + chars + '\nLines: ' + lines + '\nWords: ' + words,
      'Word Counter'
    );

    var label = await TextEditPlus.dialog.prompt(
      'Save these stats under what label?',
      'untitled',
      'Word Counter'
    );
    if (label !== null) {
      TextEditPlus.toast('Stats labeled "' + label + '" (not persisted in demo)', 'info', 3000);
    }
  }
})();
