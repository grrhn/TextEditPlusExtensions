// Base64 Encode/Decode — operates on the current selection (or the entire
// document when no selection). Uses TextEncoder so non-ASCII (Turkish, etc.)
// round-trips correctly through UTF-8.

function transformSelection(fn) {
  var sel = editor.getSelection();
  var model = editor.getModel();
  if (!model) return;
  var range = (sel && !sel.isEmpty()) ? sel : model.getFullModelRange();
  try {
    var result = fn(model.getValueInRange(range));
    editor.executeEdits('base64-tools', [{ range: range, text: result }]);
  } catch (e) {
    TextEditPlus.toast('Base64 error: ' + e.message, 'error', 2500);
  }
}

function encode(text) {
  // btoa works on Latin-1; encode UTF-8 first.
  var bytes = new TextEncoder().encode(text);
  var binary = '';
  for (var i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

function decode(b64) {
  var binary = atob(b64.trim());
  var bytes = new Uint8Array(binary.length);
  for (var i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return new TextDecoder().decode(bytes);
}

TextEditPlus.commands.register({
  id: 'base64-tools.encode',
  name: 'Base64: Encode',
  exec: function() {
    transformSelection(encode);
    TextEditPlus.toast('Encoded', 'success', 1200);
  }
}, extensionId);

TextEditPlus.commands.register({
  id: 'base64-tools.decode',
  name: 'Base64: Decode',
  exec: function() {
    transformSelection(decode);
    TextEditPlus.toast('Decoded', 'success', 1200);
  }
}, extensionId);
