// URL Encode/Decode — works on the current selection (or whole document).

function transformSelection(fn) {
  var sel = editor.getSelection();
  var model = editor.getModel();
  if (!model) return;
  var range = (sel && !sel.isEmpty()) ? sel : model.getFullModelRange();
  try {
    editor.executeEdits('url-tools', [{ range: range, text: fn(model.getValueInRange(range)) }]);
  } catch (e) {
    TextEditPlus.toast('URL error: ' + e.message, 'error', 2500);
  }
}

TextEditPlus.commands.register({
  id: 'url-tools.encode',
  name: 'URL: Encode',
  description: 'Percent-encode reserved characters',
  exec: function() {
    transformSelection(encodeURIComponent);
    TextEditPlus.toast('Encoded', 'success', 1200);
  }
}, extensionId);

TextEditPlus.commands.register({
  id: 'url-tools.decode',
  name: 'URL: Decode',
  description: 'Decode percent-encoded text',
  exec: function() {
    transformSelection(decodeURIComponent);
    TextEditPlus.toast('Decoded', 'success', 1200);
  }
}, extensionId);

TextEditPlus.commands.register({
  id: 'url-tools.encode-full',
  name: 'URL: Encode (full URL)',
  description: 'encodeURI — preserves reserved chars like : / ? #',
  exec: function() {
    transformSelection(encodeURI);
    TextEditPlus.toast('Encoded', 'success', 1200);
  }
}, extensionId);
