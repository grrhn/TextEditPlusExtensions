// Markdown Lint — pushes diagnostics for every open .md model.
// Demonstrates the Markers API by running a tiny ruleset on every
// content change. No worker needed; the rules are linear-time over
// the document so they're cheap enough to run on each edit.

const MAX_LINE_LENGTH = 120;
const SEVERITY = { error: 8, warning: 4, info: 2, hint: 1 };

function isMarkdown(model) {
  if (!model) return false;
  if (model.getLanguageId && model.getLanguageId() === 'markdown') return true;
  // Fallback for models whose language id wasn't set explicitly.
  var uri = model.uri && model.uri.toString();
  return !!(uri && (uri.endsWith('.md') || uri.endsWith('.markdown')));
}

function lintModel(model) {
  if (!isMarkdown(model)) {
    TextEditPlus.markers.clear(extensionId, model);
    return;
  }

  const text = model.getValue();
  const lines = text.split(/\r?\n/);
  const markers = [];
  const headingsSeen = {};

  let inCodeFence = false;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const ln = i + 1;

    // Toggle fenced code blocks — skip lint inside them.
    if (line.match(/^```/)) { inCodeFence = !inCodeFence; continue; }
    if (inCodeFence) continue;

    // Rule: line length
    if (line.length > MAX_LINE_LENGTH) {
      markers.push({
        startLineNumber: ln, startColumn: MAX_LINE_LENGTH + 1,
        endLineNumber:   ln, endColumn:   line.length + 1,
        message: 'Line exceeds ' + MAX_LINE_LENGTH + ' characters (' + line.length + ').',
        severity: SEVERITY.info
      });
    }

    // Rule: images without alt text — `![](url)` is bad for a11y/SEO.
    const imgRe = /!\[([^\]]*)\]\(([^)]+)\)/g;
    let m;
    while ((m = imgRe.exec(line)) !== null) {
      if (!m[1].trim()) {
        markers.push({
          startLineNumber: ln, startColumn: m.index + 1,
          endLineNumber:   ln, endColumn:   m.index + m[0].length + 1,
          message: 'Image is missing alt text. Add a description between the brackets.',
          severity: SEVERITY.warning
        });
      }
    }

    // Rule: duplicate headings — surprises link generators (anchor collisions).
    const h = line.match(/^(#{1,6})\s+(.+?)\s*$/);
    if (h) {
      const slug = h[2].toLowerCase().replace(/[^a-z0-9]+/g, '-');
      if (headingsSeen[slug] !== undefined) {
        markers.push({
          startLineNumber: ln, startColumn: 1,
          endLineNumber:   ln, endColumn:   line.length + 1,
          message: 'Heading collides with line ' + headingsSeen[slug] +
                   ' — both generate the same anchor "#' + slug + '".',
          severity: SEVERITY.warning
        });
      } else {
        headingsSeen[slug] = ln;
      }
    }
  }

  TextEditPlus.markers.set(extensionId, model, markers);
}

// Lint everything currently open, then track future changes.
monaco.editor.getModels().forEach(lintModel);

// Re-lint on edit. Debounced lightly so big paste-floods don't thrash.
var pending = new Map();
function scheduleLint(model) {
  if (pending.has(model)) clearTimeout(pending.get(model));
  pending.set(model, setTimeout(function() {
    pending.delete(model);
    lintModel(model);
  }, 250));
}

var disposables = [];
disposables.push(monaco.editor.onDidCreateModel(function(m) {
  lintModel(m);
  disposables.push(m.onDidChangeContent(function() { scheduleLint(m); }));
}));
monaco.editor.getModels().forEach(function(m) {
  disposables.push(m.onDidChangeContent(function() { scheduleLint(m); }));
});

TextEditPlus.setPluginInit(extensionId,
  function init() {
    TextEditPlus.toast('Markdown Lint active', 'success', 1500);
  },
  function destroy() {
    pending.forEach(function(t) { clearTimeout(t); });
    pending.clear();
    disposables.forEach(function(d) { try { d.dispose(); } catch (e) {} });
    // markers are auto-cleared by _disposeExt anyway, but this is explicit.
    TextEditPlus.markers.clear(extensionId);
  }
);
