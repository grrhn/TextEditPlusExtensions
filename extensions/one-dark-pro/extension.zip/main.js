// One Dark Pro — sample TextEdit+ theme extension.
//
// The extension JS is invoked with the following arguments by the host:
//   (TextEditPlus, monaco, editor, data, extensionId, Android)
// `Android` is intentionally undefined here — the host bridge is sandboxed away.

TextEditPlus.themes.define('one-dark-pro', {
  base: 'vs-dark',
  inherit: true,
  rules: [
    { token: 'comment',           foreground: '5c6370', fontStyle: 'italic' },
    { token: 'keyword',           foreground: 'c678dd' },
    { token: 'string',            foreground: '98c379' },
    { token: 'number',            foreground: 'd19a66' },
    { token: 'type',              foreground: 'e5c07b' },
    { token: 'function',          foreground: '61afef' },
    { token: 'variable',          foreground: 'e06c75' },
    { token: 'constant',          foreground: 'd19a66' },
    { token: 'operator',          foreground: '56b6c2' },
    { token: 'delimiter',         foreground: 'abb2bf' }
  ],
  colors: {
    'editor.background':            '#282c34',
    'editor.foreground':            '#abb2bf',
    'editor.lineHighlightBackground': '#2c313c',
    'editorCursor.foreground':      '#528bff',
    'editor.selectionBackground':   '#3e4451',
    'editorWhitespace.foreground':  '#3b4048',
    'editorLineNumber.foreground':  '#495162',
    'editorLineNumber.activeForeground': '#abb2bf'
  }
}, extensionId, 'One Dark Pro');
