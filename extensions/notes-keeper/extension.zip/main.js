// Notes Keeper — exercises the FS API.
// Persists short text notes to the extension's sandboxed storage and
// renders them in a sidebar panel. Demonstrates read, write, listDir,
// exists, and delete.

var NOTES_FILE = 'notes.json';

async function loadNotes() {
  try {
    var has = await TextEditPlus.fs.exists(extensionId, NOTES_FILE);
    if (!has) return [];
    var txt = await TextEditPlus.fs.readFile(extensionId, NOTES_FILE);
    return JSON.parse(txt);
  } catch (e) {
    console.error('[notes-keeper load]', e);
    return [];
  }
}

async function saveNotes(notes) {
  try {
    await TextEditPlus.fs.writeFile(extensionId, NOTES_FILE, JSON.stringify(notes));
  } catch (e) {
    TextEditPlus.toast('Save failed: ' + e.message, 'error', 3000);
  }
}

async function renderPanel() {
  var notes = await loadNotes();
  var rows = notes.length === 0
    ? '<p style="color:#888;font-style:italic">No notes yet.</p>'
    : notes.map(function(n, i) {
        return '<div style="padding:8px;border:1px solid #444;border-radius:4px;margin-bottom:6px;">' +
                 '<div style="font-size:11px;color:#888;margin-bottom:4px;">' + new Date(n.t).toLocaleString() + '</div>' +
                 '<div>' + escapeHtml(n.text) + '</div>' +
                 '<div style="text-align:right;margin-top:6px;">' +
                   '<button data-action="notes-keeper.delete-' + i + '">Delete</button>' +
                 '</div>' +
               '</div>';
      }).join('');

  TextEditPlus.sidebar.update('notes-keeper.panel',
    '<h3 style="margin-top:0">Notes Keeper</h3>' +
    '<p style="color:#888;font-size:12px">' + notes.length + ' note(s) saved to extension storage</p>' +
    '<div style="margin-bottom:12px;">' +
      '<button data-action="notes-keeper.add">+ Add note from selection</button>' +
      '<button data-action="notes-keeper.clear" style="margin-left:6px;">Clear all</button>' +
    '</div>' +
    rows
  );

  // Register one-shot delete commands for each note's index. Stale commands
  // from prior renders are overwritten harmlessly because register() is
  // keyed by command id.
  notes.forEach(function(n, i) {
    TextEditPlus.commands.register({
      id:   'notes-keeper.delete-' + i,
      name: 'Notes: delete entry ' + i,
      exec: function() {
        loadNotes().then(function(arr) {
          arr.splice(i, 1);
          return saveNotes(arr);
        }).then(renderPanel);
      }
    }, extensionId);
  });
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, function(c) {
    return ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' })[c];
  });
}

TextEditPlus.commands.register({
  id: 'notes-keeper.add',
  name: 'Notes Keeper: Add note from selection',
  exec: async function() {
    var sel = editor.getSelection();
    var model = editor.getModel();
    var text = (sel && !sel.isEmpty() && model) ? model.getValueInRange(sel) : '';
    if (!text) {
      text = await TextEditPlus.dialog.prompt('Note text:', '', 'New note');
      if (text === null) return;
    }
    if (!text || text.trim() === '') return;
    var notes = await loadNotes();
    notes.unshift({ text: text, t: Date.now() });
    await saveNotes(notes);
    TextEditPlus.toast('Note saved', 'success', 1500);
    renderPanel();
  }
}, extensionId);

TextEditPlus.commands.register({
  id: 'notes-keeper.clear',
  name: 'Notes Keeper: Clear all notes',
  exec: async function() {
    var confirm = await TextEditPlus.dialog.confirm('Delete all notes?', 'Notes Keeper');
    if (!confirm) return;
    await TextEditPlus.fs.deleteFile(extensionId, NOTES_FILE);
    TextEditPlus.toast('All notes cleared', 'info', 1500);
    renderPanel();
  }
}, extensionId);

TextEditPlus.sidebar.register({
  id:    'notes-keeper.panel',
  title: 'Notes',
  icon:  'NK',
  html:  '<p>Loading…</p>'
}, extensionId);

renderPanel();
