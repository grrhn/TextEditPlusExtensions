// TOML Language Support — sample TextEdit+ language extension.

TextEditPlus.languages.register({
  id: 'toml',
  extensions: ['.toml', '.tml'],
  aliases: ['TOML', 'toml'],
  mimetypes: ['application/toml']
}, extensionId);

TextEditPlus.languages.setMonarchTokensProvider('toml', {
  tokenizer: {
    root: [
      [/#.*$/,                              'comment'],
      [/\[\[[^\]]+\]\]/,                    'metatag'],
      [/\[[^\]]+\]/,                        'tag'],
      [/[A-Za-z_][A-Za-z0-9_.-]*(?=\s*=)/,  'key'],
      [/=/,                                  'operator'],
      [/"([^"\\]|\\.)*"/,                   'string'],
      [/'[^']*'/,                            'string'],
      [/\b(true|false)\b/,                  'keyword'],
      [/-?\d{4}-\d{2}-\d{2}(T\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:\d{2})?)?/, 'number.date'],
      [/-?\d+\.\d+([eE][+-]?\d+)?/,         'number.float'],
      [/-?\d+([eE][+-]?\d+)?/,              'number'],
      [/[{}\[\],]/,                         'delimiter']
    ]
  }
}, extensionId);

TextEditPlus.languages.setLanguageConfiguration('toml', {
  comments:    { lineComment: '#' },
  brackets:    [['[', ']'], ['{', '}']],
  autoClosingPairs: [
    { open: '[', close: ']' },
    { open: '{', close: '}' },
    { open: '"', close: '"' },
    { open: "'", close: "'" }
  ],
  surroundingPairs: [
    { open: '[', close: ']' },
    { open: '{', close: '}' },
    { open: '"', close: '"' },
    { open: "'", close: "'" }
  ]
}, extensionId);
